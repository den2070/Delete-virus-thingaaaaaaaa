                                           Русская Версия
Farbar Recovery Scan Tool-найдет вирус
Simple Unlocker-уберет ограничения
AV Block Remover-ПОЛНОСТЮ удалит вирус (если не включается скачать с случайным именем ссылка→"https://avbr.safezone.cc/rnd/"НЕ ЗАПУСКАТЬ В ЗАГРУЗКАХ НЕ БУДЕТ РАБОТАТЬ)
Process Hacker-Найди вирус и убери с него задачу и надо найти имя его(аналог дисечера задач)
                                                    

                                                English Version
Farbar Recovery Scan Tool-Will find the virus
Simple Unlocker-Will unlock restrictions
AV Block Remover-Will COMPLETELY delete the virus (if don't working download with random name link"https://avbr.safezone.cc/rnd/" and DON'T OPEN IN DOWNLOADS IT WILL NOT WORK)
Process Hacker-With this you can disable virus for one enter and you need to find name of the virus(you can do it with task manager)
        


                                              Українська версія
                                                 (мені було лінь перекладати і я за допомогою гугл перекладача переклав)
Farbar Recovery Scan Tool-знайде вірус
Simple Unlocker-прибере обмеження
AV Block Remover-ПОВНІСТЮ видалить вірус (якщо не включається завантажити з випадковим ім'ям →"https://avbr.safezone.cc/rnd/" НЕ ВІДКРИВАТИ У ЗАВАНТАЖЕННЯХ НЕ БУДЕ ПРАЦЮВАТИ)
Process Hacker-Знайди вірус і прибери з нього завдання і треба знайти ім'я його (схоже на диспетчер завдань )